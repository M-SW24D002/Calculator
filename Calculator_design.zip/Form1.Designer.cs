﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnClear = new Button();
            btnDivide = new Button();
            btnMultiply = new Button();
            btnSubtract = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btnAdd = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btnEquals = new Button();
            btn0 = new Button();
            btnDecimal = new Button();
            textdisplay = new Label();
            SuspendLayout();
            // 
            // btnClear
            // 
            btnClear.BackColor = SystemColors.ActiveCaption;
            btnClear.FlatAppearance.BorderSize = 0;
            btnClear.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(43, 112);
            btnClear.Margin = new Padding(4);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(79, 80);
            btnClear.TabIndex = 4;
            btnClear.Text = "del";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnDivide
            // 
            btnDivide.BackColor = SystemColors.ActiveCaption;
            btnDivide.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnDivide.Location = new Point(128, 112);
            btnDivide.Margin = new Padding(4);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(79, 80);
            btnDivide.TabIndex = 5;
            btnDivide.Text = "%";
            btnDivide.UseVisualStyleBackColor = false;
            // 
            // btnMultiply
            // 
            btnMultiply.BackColor = SystemColors.ActiveCaption;
            btnMultiply.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnMultiply.Location = new Point(214, 112);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(79, 80);
            btnMultiply.TabIndex = 6;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = false;
            // 
            // btnSubtract
            // 
            btnSubtract.BackColor = SystemColors.ActiveCaption;
            btnSubtract.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnSubtract.Location = new Point(299, 112);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(79, 80);
            btnSubtract.TabIndex = 7;
            btnSubtract.Text = "-";
            btnSubtract.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            btn7.BackColor = Color.FromArgb(251, 228, 216);
            btn7.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn7.Location = new Point(43, 199);
            btn7.Name = "btn7";
            btn7.Size = new Size(79, 80);
            btn7.TabIndex = 8;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            btn8.BackColor = Color.FromArgb(251, 228, 216);
            btn8.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn8.Location = new Point(128, 199);
            btn8.Name = "btn8";
            btn8.Size = new Size(79, 80);
            btn8.TabIndex = 9;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            btn9.BackColor = Color.FromArgb(251, 228, 216);
            btn9.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn9.Location = new Point(214, 199);
            btn9.Name = "btn9";
            btn9.Size = new Size(79, 80);
            btn9.TabIndex = 10;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = SystemColors.ActiveCaption;
            btnAdd.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnAdd.Location = new Point(299, 199);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(79, 168);
            btnAdd.TabIndex = 11;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            btn4.BackColor = Color.FromArgb(251, 228, 216);
            btn4.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn4.Location = new Point(43, 287);
            btn4.Name = "btn4";
            btn4.Size = new Size(79, 80);
            btn4.TabIndex = 12;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            btn5.BackColor = Color.FromArgb(251, 228, 216);
            btn5.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn5.Location = new Point(128, 287);
            btn5.Name = "btn5";
            btn5.Size = new Size(79, 80);
            btn5.TabIndex = 13;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            btn6.BackColor = Color.FromArgb(251, 228, 216);
            btn6.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn6.Location = new Point(214, 287);
            btn6.Name = "btn6";
            btn6.Size = new Size(79, 80);
            btn6.TabIndex = 14;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = false;
            // 
            // btn1
            // 
            btn1.BackColor = Color.FromArgb(251, 228, 216);
            btn1.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn1.Location = new Point(43, 374);
            btn1.Name = "btn1";
            btn1.Size = new Size(79, 80);
            btn1.TabIndex = 15;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            btn2.BackColor = Color.FromArgb(251, 228, 216);
            btn2.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn2.Location = new Point(128, 374);
            btn2.Name = "btn2";
            btn2.Size = new Size(79, 80);
            btn2.TabIndex = 16;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            btn3.BackColor = Color.FromArgb(251, 228, 216);
            btn3.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn3.Location = new Point(214, 374);
            btn3.Name = "btn3";
            btn3.Size = new Size(79, 80);
            btn3.TabIndex = 17;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = false;
            // 
            // btnEquals
            // 
            btnEquals.BackColor = SystemColors.ActiveCaption;
            btnEquals.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnEquals.Location = new Point(299, 374);
            btnEquals.Name = "btnEquals";
            btnEquals.Size = new Size(79, 168);
            btnEquals.TabIndex = 18;
            btnEquals.Text = "Enter";
            btnEquals.UseVisualStyleBackColor = false;
            // 
            // btn0
            // 
            btn0.BackColor = Color.FromArgb(251, 228, 216);
            btn0.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btn0.Location = new Point(43, 461);
            btn0.Name = "btn0";
            btn0.Size = new Size(164, 80);
            btn0.TabIndex = 19;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = false;
            // 
            // btnDecimal
            // 
            btnDecimal.BackColor = Color.FromArgb(251, 228, 216);
            btnDecimal.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            btnDecimal.Location = new Point(214, 461);
            btnDecimal.Name = "btnDecimal";
            btnDecimal.Size = new Size(79, 80);
            btnDecimal.TabIndex = 20;
            btnDecimal.Text = ".";
            btnDecimal.UseVisualStyleBackColor = false;
            // 
            // textdisplay
            // 
            textdisplay.AutoSize = true;
            textdisplay.BackColor = Color.FromArgb(45, 45, 55);
            textdisplay.Font = new Font("Segoe UI", 26F);
            textdisplay.ForeColor = Color.White;
            textdisplay.Location = new Point(329, 49);
            textdisplay.Name = "textdisplay";
            textdisplay.Size = new Size(49, 60);
            textdisplay.TabIndex = 21;
            textdisplay.Text = "0";
            textdisplay.TextAlign = ContentAlignment.TopRight;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(25, 0, 25);
            ClientSize = new Size(425, 578);
            Controls.Add(textdisplay);
            Controls.Add(btnDecimal);
            Controls.Add(btn0);
            Controls.Add(btnEquals);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btnAdd);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(btnSubtract);
            Controls.Add(btnMultiply);
            Controls.Add(btnDivide);
            Controls.Add(btnClear);
            Font = new Font("Segoe UI", 10F);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnClear;
        private Button btnDivide;
        private Button btnMultiply;
        private Button btnSubtract;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnAdd;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btnEquals;
        private Button btn0;
        private Button btnDecimal;
        private Label textdisplay;
    }
}
